let img1;
let img2;
let img3;
let img4;
let img5;
let img6;
let img7;
let img8;
let img9;
let img10;
let img11;
let img12;
let img13;
let img14;
let img15;

function preload(){
  img1 = createImg('https://tse1.explicit.bing.net/th?id=OIP.smHqQX_GmcjnsUXSC6-7ewHaEV&pid=Api&P=0&w=289&h=169', 'eugenia cooney');
  img2 = createImg('http://24.media.tumblr.com/00f171c160f4a552f8ca90002989744a/tumblr_mm0lmeeFFZ1qe1uqko1_500.gif', 'sparkle');
  img3 = createImg('http://24.media.tumblr.com/00f171c160f4a552f8ca90002989744a/tumblr_mm0lmeeFFZ1qe1uqko1_500.gif', 'sparkle');
  img4 = createImg('https://klyker.com/wp-content/uploads/2015/07/woman-with-insane-body-modifications-6.jpg', 'dylan brady');
  img5 = createImg('http://i.huffpost.com/gen/498220/thumbs/r-KETAMINE-DRUG-METHOXETAMINE-large570.jpg', 'ketamine');
  img6 = createImg('https://tse4.mm.bing.net/th?id=OIP.k2h1nuwwus-yIgySuVt2kwHaEK&pid=Api&P=0&w=302&h=169', 'euphoria');
  img7 = createImg('https://tse1.mm.bing.net/th?id=OIP.chE_JyrZC8ESGApQ5wisGwAAAA&pid=Api&P=0&w=172&h=172', 'anti christian');
  img8 = createImg('https://i.ytimg.com/vi/tj4sOjHi7sE/hqdefault.jpg', 'area 51')
  img9 = createImg('https://youaremom.com/wp-content/uploads/2019/02/siblings-posing-together-smiling.jpg', 'missouri');
  img10 = createImg('https://www.theladders.com/wp-content/uploads/hug_190429.jpg', 'physical touch');
  img11 = createImg('http://www.healthcare-online.org/images/10405017/body-odor.jpg', 'stinky');
  img12 = createImg('https://cdn.vox-cdn.com/thumbor/H2oISYktPQ0lNV0zlWXHQMdQUrE=/0x0:3045x2029/920x613/filters:focal(1293x725:1779x1211):format(webp)/cdn.vox-cdn.com/uploads/chorus_image/image/66025862/1197574316.jpg.0.jpg', 'tom brady');
  img13 = createImg('https://www.georgianjournal.ge/images/georgianews/2018/March/culture/imagine5.jpg', 'imagine dragons');
  img14 = createImg('https://tse2.mm.bing.net/th?id=OIP.M9gK090xkEqjzcqm9O19FgHaEK&pid=Api&P=0&w=295&h=166', 'scientology');
  img15 = createImg('https://images.gmanews.tv/webpics/2020/07/2020-07-08T071142Z_1442775454_RC2VOH95XAFN_RTRMADP_3_USA-ELECTION-KANYE-WEST_2020_07_09_05_53_34.JPG', 'kanye west');

}
function setup() {
  createCanvas(825, 1500);
}
function draw() {
    background(178,190,181);

// stripe
  noStroke();
  fill(0);
  rect(25, 30, 775, 182);

// heading
  fill(300);
  textFont('times new roman', 58);
  text('TALLY', 35, 90);
  text('DESK', 110, 140);
  text('NEWSLETTER', 175, 190);
  fill(245,208,0);
  textFont('script mt', 30);
  text('premium edition', 580, 60);

// borders
  noStroke(0);
  fill(0);
  rect(25, 120, 25, 1350);
  rect(775, 120, 25, 1350);
  rect(25, 1440, 775, 30);
  img2.position(555, 40);
  img2.size(20, 20);
  img3.position(775, 40);
  img3.size(20, 20);
  
// eugenia cooney
  stroke(300);
  fill(300);
  rect(60, 225, 280, 290); 
  noStroke(0);
  textFont('calibri', 22);
  fill(0);
  text("Eugenia Cooney dies in armed robbery", 80, 455, 250);
  img1.position(75, 240);
  img1.size(250, 200);

// euphoria
  stroke(300);
  fill(300);
  rect(350, 225, 250, 290);
  noStroke(0);
  fill(0);
  textFont('calibri', 19);
  text('Euphoria creators declare that cellular mitosis is a hoax and will be incorporating that belief into all further episodes', 370, 395, 230);
  img6.position(365, 240);
  img6.size(220, 150);

// god drug
  stroke(300);
  fill(300);
  rect(610, 225, 155, 190);
  noStroke(0);
  fill(0);
  textFont('calibri', 20);
  text("Teenagers are using a new drug that allows them to 'See God'", 620, 315, 150);
  img5.position(625, 240);
  img5.size(125, 70);

// chance the rapper
  stroke(300);
  fill(300);
  rect(60, 525, 230, 310);
  noStroke(0);
  fill(0);
  textFont('calibri', 20);
  text('Chance The Rapper denounces Christianity after marrying into the royal family', 75, 730, 230);
  img7.position(75, 540);
  img7.size(200, 180);
  
// cryptocussy
  stroke(300);
  fill(300);
  rect(300, 525, 300, 185);
  noStroke(0);
  fill(0);
  textFont('calibri', 20);
  text("New element found near Area 51 scientists are calling 'Cryptocussy'", 315, 650, 300);
  img8.position(315, 540);
  img8.size(270, 100);
  
// 100 gecs
  stroke(300);
  fill(300);
  rect(610, 425, 155, 285);
  noStroke(0);
  fill(0);
  textFont('calibri', 20);
  text('Dylan Brady of 100 gecs dies at age 31 due to heart failure', 620, 600, 150);
  img4.position(625, 440);
  img4.size(125, 150);

// missouri
  stroke(300);
  fill(300);
  rect(300, 720, 465, 250);
  noStroke(0);
  fill(0);
  textFont('calibri', 20);
  text('Missouri legalizes marraige between immediate family', 310, 945, 450);
  img9.position(315, 735);
  img9.size(435, 200);

//  government
  stroke(300);
  fill(300);
  rect(60, 845, 230, 210);
  noStroke();
  fill(0);
  textFont('calibri', 22);
  text('US. Government bans physical contact until further notice', 75, 970, 200);
  img10.position(75, 860);
  img10.size(200, 100);
  
// stinky
  stroke(300);
  fill(300);
  rect(300, 980, 200, 200);
  noStroke(0);
  fill(0);
  textFont('calibri', 19);
  text('New studies find that hypnosis can be used to eliminate body odor', 310, 1100, 190);
  img11.position(315, 995);
  img11.size(170, 100);
  
// tom brady
  stroke(300);
  fill(300);
  rect(60, 1065, 230, 365);
  noStroke(0);
  fill(0);
  textFont('calibri', 25);
  text('Formerly retired NBA quarterback Tom Brady is now working as a middle school art teacher', 75, 1240, 200);
  img12.position(75, 1080);
  img12.size(200, 150);

// imagine dragons
  stroke(300);
  fill(300);
  rect(510, 980, 255, 200);
  noStroke(0);
  fill(0);
  textFont('calibri', 20);
  text('Lead singer of Imagine Dragons arrested for child pornography', 525, 1105, 250);
  img13.position(525, 995);
  img13.size(225, 100);

// scientology
  stroke(300);
  fill(300);
  rect(300, 1190, 265, 240);
  noStroke(0);
  fill(0);
  textFont('calibri', 19);
  text('Historians find evidence to support that founder of Scientology was gay', 320, 1360, 250);
  img14.position(315, 1205);
  img14.size(235, 150);

// kanye west
  stroke(300);
  fill(300);
  rect(575, 1190, 190, 240);
  noStroke(0);
  fill(0);
  textFont('calibri', 17);
  text('President Kanye West declares that America is under Marshal Law until his new album is released', 585, 1340, 190);
  img15.position(585, 1205);
  img15.size(170, 130);
}